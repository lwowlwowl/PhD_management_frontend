const BASE_URL = 'http://localhost:8080'; // 后端服务地址

export default BASE_URL;
